import { Component, OnInit } from '@angular/core';
import { HomeService } from '../home.service';
import { THIS_EXPR } from '../../../node_modules/@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public blockList = []
  constructor() {
    for (var i = 1; i <= 36; i++) {
      this.blockList[i - 1] = { index: i, circleFlag: false }
    }
    this.setCircleFlags(6)
  }

  ngOnInit() {
    // this.getPostsData()
    // setTimeout(() => this.getTopPosts(),1000)
  }
  generateRandom(n) {
    let randomNums = []
    while (randomNums.length < n) {
      let num = Math.floor((Math.random() * 36) + 1);
      if (randomNums.indexOf(num) == -1) {
        randomNums.push(num)
      }
    }
    console.log("random nums:",randomNums)
    return randomNums;
  }
  setCircleFlags(n) {
    let randomNums = this.generateRandom(n)
    for (var i = 0; i < 36; i++) {
      if (randomNums.indexOf(this.blockList[i].index) !== -1) {
        this.blockList[i].circleFlag = true
      }
    }
  }


}
